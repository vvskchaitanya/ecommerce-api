package com.vvsk.html2csv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Html2csvApplication {

	public static void main(String[] args) {
		SpringApplication.run(Html2csvApplication.class, args);
	}

}
